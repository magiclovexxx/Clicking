<form class="formSchedule" action="<?=cn('ajax_post_now')?>" data-action="<?=cn('ajax_save_schedules')?>">
    <div class="row">
        <div class="clearfix"></div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <h2>
                        <i class="fa fa-bars" aria-hidden="true"></i> <?=l('Content hot trend')?>
                    </h2>
                </div>
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane fade in active" id="message_1">
                                                <div class="header">
                            <div class="form-inline form-manage-groups">
                                <div class="form-group wa">
                                    <select class="form-control mr5 filter_account" name="account">
                                       <!-- <option value=""><?=l('All category')?></option> -->
                                        <?php if(!empty($category_data)){
                                        foreach ($category_data as $row) {
                                        ?>
                                        <option value="<?=$row->name?>"><?=$row->name?></option>
                                        <?php }}?>
                                    </select>
                                </div>
                                <div class="form-group wa">
                                    <select class="form-control mr5 categories">
                                        <option><?=l('All categories')?></option>
                                        <?php if(!empty($categories)){
                                        foreach ($categories as $row) {
                                        ?>
                                        <option value="<?=$row->id?>" <?=(session("category") == $row->id)?"selected":""?>><?=$row->name?></option>
                                        <?php }}?>
                                    </select>
                                </div> 
                                <div class="form-group wa mr15">
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn bg-blue-grey waves-effect btnAddCategory" data-type="message" data-toggle="tooltip" title="<?=l('Add new category')?>" data-action="<?=cn('ajax_add_category')?>"><i class="fa fa-plus" aria-hidden="true"></i></button>
                                        <button type="button" class="btn bg-blue-grey waves-effect btnUpdateCategory" data-type="post" data-toggle="tooltip" title="<?=l('Update category')?>" data-action="<?=cn('ajax_update_category')?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                        <button type="button" class="btn bg-blue-grey waves-effect btnDeleteCategory" data-toggle="tooltip" title="<?=l('Remove category selected')?>"> <i class="fa fa-trash-o" aria-hidden="true"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="body p0">
                            <table class="table table-bordered table-striped table-hover js-dataTable dataTable mb0">
                                <thead>
                                    <tr>
                                        <th><?=l('Category')?></th>
                                        <th><?=l('Link content')?></th>
                                        <th><?=l('Shares')?></th>
                                        <th><?=l('Likes')?></th>
                                        <th><?=l('Status')?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                   
                                    <?php if(!empty($result)){
                                    foreach ($result as $key => $row) {
                                    ?>
                                        <tr class="post-pending">
                                            <td><?=$row->cat_data?></td> 
                                            <td><a href="https://facebook.com/<?=$row->description?>" target="_blank"><i class="fa fa-link" aria-hidden="true"></i> <?=l('View Content')?></a></td>
                                            <td><?=$row->caption?></td>
                                            <td><?=$row->title?></td>
                                            <td><?=$row->message?></td>
                                        </tr>
                                    <?php }}?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </div>
</form>

<div class="modal fade" id="modal-update-category" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-blue-grey">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel"><?=l('Select category')?></h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <select class="form-control mr5 category_id">
                        <option value="">----</option>
                        <?php if(!empty($categories)){
                        foreach ($categories as $row) {
                        ?>
                        <option value="<?=$row->id?>" <?=(session("category") == $row->id)?"selected":""?>><?=$row->name?></option>
                        <?php }}?>
                    </select>
                </div>   
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-modal-update-category"><i class="fa fa-floppy-o" aria-hidden="true"></i> <?=l('Update')?></button>
            </div>
        </div>
    </div>
</div>