<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class package_settings_model extends MY_Model {
	public function __construct(){
		parent::__construct();
	}
}
