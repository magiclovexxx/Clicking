<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class cron extends MX_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model(get_class($this).'_model', 'model');
	}
	
		public function test1 (){
		    
		    echo '<pre>';
		   // $groups = '469243736423516';
		   $groups =  '100010760317952';
		  //  $groups = '1794200674197581'; //page da like,  print_r ($get_friendinfos->data[200]->likes->count); // lay so luong like
		  // $groups = '592308647602812'; //page chua like, lay dc het thong tin bai viet
		  //  $groups = '100002244978306'; //id bat ky - feed: lay thong tin bai viet cong khai
		   //  $groups = '1398763806849013'; //nhom cong khai
		  //$groups = '173113206770306'; // page toan tran
		    $row->fid= "100004384958635";
		    $access_token = 'EAAAAAYsX7TsBAMGHk6v8vOwR6hAy4mwGTDjZA6Uki1OcjsNN6Va16OZCs3GhdMOZBTMYWcHuIBZAKZBaRLwf1jylmAcemBOflZC14eZCJFwYZBoZCyt98cdUFMqNrZAM17qsSCiaAeT2UDnoPgZBBpW3ZB9PIVVxkZAxGHcvKM3ZBSOEazpVZA4YTcGFmU0JWbK4kndrnK73KBxnbhOUXuK14wrZCeGN';
           // $get_friendinfos = file_get_contents_curl("https://graph.facebook.com/".$groups."/feed?limit=1000&access_token=".$access_token);
            // $get_friendinfos = file_get_contents_curl("https://graph.facebook.com/".$groups."/broadcast_messages?limit=1000&access_token=".$access_token);
            $get_friendinfos = file_get_contents_curl("https://graph.facebook.com/v3.0/me/feed?access_token=".$access_token);
            
          // $get_idpost = file_get_contents_curl("https://graph.facebook.com/".$row->fid."/feed?fields=id&limit=3&access_token=".$access_token);
          //  $get_idpost = file_get_contents_curl("https://graph.facebook.com/".$row->fid."/posts?fields=id&limit=1&access_token=".$access_token);

            print_r ($get_idpost);
            // print_r (session('uid'));
            print_r ($get_friendinfos);
		}

	public function get_data_page (){
	    echo '<pre>';
	    
	    $tonghop = "236367346550727
";
	    $phunu = "998858630231366
2074013472825244
1888281824729455
	    528055814042582
1619051205052330
781294888571140
506917206022720";

        $haihuoc = "552127024828401
1616182405300338
226709920794699
796263053785034
218850754980782
173518519458452";

        $caunoihay = "355117167903718
479389995564896
1781021405443042
376575922383028
336719133049023
517531261594102
";
        $lamdep = "654419654642830
343766205765852
277841999017825
160602294146010
461627610668978
585232168292077
429447273846745
";
        $pages = explode ("\n", $caunoihay);

         $account   = $this->model->fetch("*", token, "status=1");

         //print_r ($selectdata);
         $access_token = $account[1]->token;
         //$access_token
         foreach ($pages as $key=>$page) {
            $get_groupsif = file_get_contents_curl("https://graph.facebook.com/".$page."/feed?limit=100&access_token=".$access_token);
            $datapost = $get_groupsif->data;
            if(!empty($datapost)){
                
                foreach ($datapost as $key=> $data1){
                    $selectdata   = $this->model->fetch("*", save_data, "status=1 AND description = '".$data1->id."'");
                if(empty($selectdata)){
                    if ($data1->shares->count >30){
                        //print_r ($data1->shares->count); 
                        $data2 = array(
                            "title" => $data1->likes->count,
                            "caption" => $data1->shares->count,
                            "url" => $data1->link,
                            "name" => $data1->from->name,
                            "message" => $data1->message,
                            "cat_data" => "Tổng hợp",
                            "category" => "post",
                            "status" => "1",
                            "type"  => "link",
                            "description" => $data1->id,
                            
                            );
                       // echo "</br>";
                        $this->db->insert(save_data, $data2);
                        $i++;
                    }
                }
            }}
         }
         
        // print_r($data1);
	}

	public function auto_like_allfriends ()    // auto like all friend agency account
	{
	      // lay all list account
	        
	        $datalikes = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where("description = 'auto_like_all'")
	    ->where('time_post <= ', NOW)
	    ->get()->result();
	        
        foreach ($datalikes as $key => $row){
            
            $friends   = $this->model->fetch("pid", FACEBOOK_GROUPS,  "status = 1 AND account_id = {$row->account_id} AND type = 'friend'");
            $result   = $this->model->fetch("*", FACEBOOK_ACCOUNTS, "status=1 AND id={$row->account_id} ");
            
            $row->access_token = $result[0]->access_token;
            
        	$response = (object)Fb_Post((object)$row);
        	
        	$arr_update = "";
			$arr_update = array(
				'result' => (isset($response->id) && $response->id != "")?$response->id:"",
				'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
			);
		 
			$countfriend = $row->bot_like - 1;
			if($countfriend < 0){
			    $countfriend = count($friends);
			}
		    $arr_update['bot_like'] = $countfriend;
			$arr_update['group_id'] = $friends[$countfriend]->pid;
			$arr_update['time_post'] = date("Y-m-d H:i:s", strtotime(NOW) + rand(10,30));
			
			$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
	        
	    }
	}

 public function getnewcustomerpost ()
	{
	    echo '<pre>';
	    $account     = $this->model->fetch("*", FACEBOOK_ACCOUNTS, "status=1"); 
       
	    foreach ($account as $key => $row) {
	    	$checklive = file_get_contents_curl("https://graph.facebook.com/me?fields=id&access_token=".$row->access_token);
	    	
	    	if (!empty($checklive->id))
	    	{
	    		$access_token = $row->access_token;
	    		break;
	    	}

	    }
        
		$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_ACCOUNTS)
	    ->get()->result(); 
	    
	  	$accountindexs = $this->model->fetch("*", save_data, "category = 'postid'"); 

	  	// lay so thu tu acc de lay bai viet moi
	  	$accountindex = $accountindexs[0]->uid;

         for ($i = 0; $i<10; $i++) {
            if ($accountindex == count($result)){
	  	        $accountindex = 0;
	    	}
	    	
            $get_idpost = file_get_contents_curl("https://graph.facebook.com/".$result[$accountindex]->fid."/posts?fields=id&limit=1&access_token=".$access_token);
            
            // update new post id vao cot password
            $idss['cookies'] = $get_idpost->data[0]->id;
            $this->db->update(FACEBOOK_ACCOUNTS, $idss, "fid = {$result[$accountindex]->fid} ");
            
            // update thu tu ban be da lay new post id
            $data["uid"] = $accountindex++;
             $this->db->update(save_data, $data, "category = 'postid'");

        }
        
	}
	
    public function auto_all (){
        echo '<pre>';
        $result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_ACCOUNTS)
	    ->where('status = ', 1)
	    ->get()->result();
	    
        $get_tokenlike  =  $this->model->fetch("*", token, "status = 1");
      
        // lay id bai viet cua khach
        foreach ($result as $key => $row) {
            
            // ghi du lieu like all friend
            $datalikeallfriend = $this->model->fetch("*", FACEBOOK_SCHEDULES, "account_id = {$row->id} AND description = 'auto_like_all'");
           
            if (empty ($datalikeallfriend)){
                $friends   = $this->model->fetch("pid", FACEBOOK_GROUPS,  "status = 1 AND account_id = {$row->id} AND type = 'friend'");
                 $datalikeallfriend = array (
	                    'type'          => 'like',
	                    'category'      => 'like',
	                    'group_type'    => 'friend',
	                    'group_id'      => $friends[0]->pid,
	                    'account_id'    => $row->id,
	                    'account_name'  => $row->username,
	                    'time_post'     => NOW,
	                    'description'   => 'auto_like_all',
	                    'deplay'        => rand(30,60),
	                    'status'        => 9,
	                    'changed'       => NOW,
	                    'created'       => NOW,
	                    'time_post_show'=> NOW,
	                    'bot_like'     => count($friends1),  // so luong ban be
	                   // 'auto_comment'     => count($friends1), // like ban be thu 'n'
	                );
	                $this->db->insert(FACEBOOK_SCHEDULES, $datalikeallfriend);
            }
            
            $random_likes = rand (count($get_tokenlike) - 20,count($get_tokenlike)-1); // random so luong like
            
                //auto like
            if (!empty($row->cookies)){
                // check xem post id da co dc auto chua
                $check_postid = $this->model->fetch("*", FACEBOOK_SCHEDULES, "status = 9 AND title = '".$row->cookies."' AND category = 'bulk_like'");
            
                if (empty($check_postid)){
		            $data_schedule ["title"] = $row->cookies;
		            $data_schedule ["type"] = "bulk_like";
		            $data_schedule ["description"] = "like new post";
			        $data_schedule ["category"] = "bulk_like";
                    $time_post = strtotime(NOW) + rand(60,180);
                   	$data_schedule["uid"]            = $row->uid;
	            	$data_schedule["group_type"]     = "profile";
	            	$data_schedule["account_id"]     = "0";
	            	$data_schedule["account_name"]   = $row->username;
	            	$data_schedule["group_id"]       = $row->fid;
	            	$data_schedule["name"]           = $row->fullname;
	            	$data_schedule["time_post"] = date("Y-m-d H:i:s", $time_post +     rand(120,180));
	            	$data_schedule["time_post_show"] = $data_schedule["time_post"];
	            	$data_schedule["status"]         = "9";
	            	$data_schedule["deplay"]         = rand(400,600);
	            	$data_schedule["changed"]        = NOW;
	            	$data_schedule["created"]        = NOW;
                    $data_schedule["bot_like"] = $random_likes;
	            	$data_schedule["auto_comment"]   = "";
	            	// insert auto like
	                $this->db->insert(FACEBOOK_SCHEDULES, $data_schedule);
	               	// print_r ($data_schedule);
	               	
	               	// auto comment
	               	$data_schedule["type"] = "bulk_comment";
	               	$data_schedule["category"] = "auto_seeding";
	               	$data_schedule["auto_comment"] = "$random_likes";
	               	$data_schedule["bot_like"] = "";
	               	$data_schedule["deplay"]         = rand(600,1000);
	               	$data_schedule["time_post"] = date("Y-m-d H:i:s", $time_post +     rand(500,700));
	                //$this->db->insert(FACEBOOK_SCHEDULES, $data_schedule);
                    
                }   
            }       
        }
    }
	
	public function addtoken (){
	   echo '<pre>';
        $message = explode ("\n", $message);
        print_r ($message);
        $data ="EAAAAUaZA8jlABAMcvTB2lldQ7FO6OSVF9dvBZBoaAUaKcZBsXSl5cyzW3ApqQjrBdkwqSpf1wwM9isPhA0T0d3XXWG964CJ9pQ9qb6Y5CHOsO4ih1nMn6o0HEotLIxXHfx5AaVrrwc3NihfmfTO3pKCLPZATx3xD5e1ZCaWWLFnpVj3fUrrwt";
        $data2 = explode("\n", $data);
        
        foreach ($data2 as $key=>$row) {
        	$get_postid = file_get_contents_curl("https://graph.facebook.com/me/?access_token=".$row);
	        $data3->name = $get_postid->name;
	        $data3->gioitinh = $get_postid->gender;
	        $data3->uid = $get_postid->id;    
            $data3->token = $row;    
            $this->db->insert(token, $data3);
        }
	}
	
	public function auto_seeding(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);
        echo '<pre>';

	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where("category = 'auto_seeding'")
	    ->where('time_post <= ', NOW)
	    ->get()->result();

        $get_comment = $this->model->fetch("*", SAVE_DATA, "cat_data = 'Comment'");
        
		$access_token = $this->model->fetch("*", token, "status= 1"); 
        
		if(!empty($result)){
			foreach ($result as $key => $row) {
			    if ($row->auto_comment == 0){
		        //	$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
		        }else{
		            
				    $delete       = $row->delete_post;
				    $repeat       = $row->repeat_post;
				    $repeat_time  = $row->repeat_time;
				    $repeat_end   = $row->repeat_end;
				    $time_post    = $row->time_post;
				    $deplay       = $row->deplay;
                    $message      = $row->message;
                    $auto_comment = $row->auto_comment;
				    $time_post          = strtotime(NOW) + $deplay;
				    $time_post_only_day = date("Y-m-d", $time_post);
				    $time_post_day      = strtotime($time_post_only_day);
				    $repeat_end         = strtotime($repeat_end);
				    $row->title       = $spintax->process($row->title);
				    $row->description = $spintax->process($row->description);
				    $row->image       = $spintax->process($row->image);
				    $row->caption     = $spintax->process($row->caption);
                    $arr_update   = $row;
				    $message2 = explode ("\n", $message);
				    $row->message = $message2[rand(0,count($message2)-1)];
					$row->access_token = $access_token[$auto_comment]->token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;
					
					if (empty($message)){
					    $getcomment1 = $get_comment[rand(0,count($get_comment) - 1)]->message;
					    $row->message = $getcomment1;
					}
					$response = (object)Fb_Post((object)$row);

					$arr_update = array(
					//	'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);
					$arr_update["changed"]        = NOW;
                    $arr_update["created"]        = NOW;
                    $arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);
                    $arr_update ['auto_comment'] = $auto_comment-1;
                    if (empty($message)){
                        $row->message = "";
                    	$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
                    }else{
					    $arr_update['message'] = $message;
					    $this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
                    }
			    }
			}
		}

    	echo l('Successfully');
	}
	
	public function checktoken (){
	    echo '<pre>';
	    //$access_token = $this->model->fetch("*", token); 
	    $access_token = $this->model->fetch("*", FACEBOOK_ACCOUNTS); 
        
        foreach ($access_token as $key => $row){
	        $get_postid = file_get_contents_curl("https://graph.facebook.com/me/?fields=name&access_token=".$row->access_token);

	    if(empty($get_postid->name)){
	    	$arr_update = "";
	        $arr_update['status'] = 0;
	        print_r ($row->username);
	        echo "</br";
	         $this->db->update(FACEBOOK_ACCOUNTS ,$arr_update , "id = {$row->id}");
	    }
	    else{
	        $arr_update['status'] = 1;
	    	$this->db->update(FACEBOOK_ACCOUNTS ,$arr_update , "id = {$row->id}");
	       // print_r ($get_postid);
	    }
	    
       
        }
	}
	
	
	public function auto_comment (){
	    $get_post = $this->model->fetch("*", FACEBOOK_SCHEDULES, "auto_comment >0 AND status = 3 AND category = 'post'");
	    
	    echo '<pre>';
	    $getcomment = $this->model->fetch("*", SAVE_DATA, "cat_data = 'Comment'");
	    $getcomment = $getcomment[rand(0,count($getcomment))]->message;

	    foreach ($get_post as $key => $row){
	        
	        $row->auto_comment = 0;
	        $this->db->update(FACEBOOK_SCHEDULES ,$row , "id = {$row->id}");
	        $post_id = explode("_",$row->result);
	        if($post_id[1] == 0)
	            $postid = $post_id[0];
	        else
	            $postid = $post_id[1];
	            
	        $data = array(
			"title"       => $postid,
			"caption"     => $ids,
			"category"    => "bulk_comment",
			"type"        => "bulk_comment"
		);
	         
	        $data["repeat_post"] = 1;
			$data["repeat_time"] = rand(1600,3600);
			$data["repeat_end"]  = date("Y-m-d", strtotime(NOW) + 86400* $row->auto_comment);
			
			$data["uid"]            = $row->uid;
			$data["group_type"]     = $row->group_type;
			$data["account_id"]     = $row->account_id;
			$data["account_name"]   = $row->account_name;
			$data["group_id"]       = $row->group_id;
			$data["name"]           = $row->name;
			$data["privacy"]        = $row->privacy;
			$data["message"]        = $getcomment;
			$data["time_post"]      = date("Y-m-d H:i:s", strtotime(NOW) + rand(60,200));
			$data["time_post_show"] = $data["time_post"];
			$data["status"]         = 1;
			$data["deplay"]         = $deplay;
			$data["changed"]        = NOW;
			$data["created"]        = NOW;
	        $data["auto_comment"]   = 0;
        	$this->db->insert(FACEBOOK_SCHEDULES, $data);
	    }
	}
	
	public function happy_birthday (){
	    $account = $this->model->fetch("*", FACEBOOK_ACCOUNTS, "status = 1");
	    $birthday_massage = $this->model->fetch("*", SAVE_DATA, "cat_data = 'happy birth day'");
	    echo '<pre>';
        foreach  ($account as $key => $row){
            $get_friendinfos = file_get_contents_curl("https://graph.facebook.com/".$row->fid."/friends?fields=birthday,name&limit=5000&access_token=".$row->access_token);
            $get_friendinfos = $get_friendinfos->data;

            foreach ($get_friendinfos as $xxxx => $friend_info) {
                
                $birth_day = $friend_info->birthday;
                $birthday_m = date ('m', strtotime ($birth_day));
                $birthday_d = date ('d', strtotime ($birth_day));

                // check ngay sinh nhat 
                if ((($birthday_m == date('m'))&&($birthday_d == date('d')))) {

                    $birthday_massage = $birthday_massage[rand(0,count($birthday_massage))];
                   // echo "</br>";
                    //print_r ($row->fullname);
                 //   print_r ($friend_info);
                    
                    $data = array(
					"category"    => "friend",
					"type"        => "friend",
					"url"         => $birthday_massage->url,
					"image"       => $birthday_massage->image,
					"title"       => $birthday_massage->title,
					"caption"     => $birthday_massage->caption,
					"description" => $birthday_massage->description,
					"message"     => $birthday_massage->message,
				    );
				    $data["uid"]            = session("uid");
				    $data["group_type"]     = $birthday_massage->type;
				    $data["account_id"]     = $row->account_id;
				    $data["account_name"]   = $row->fullname;
				    $data["group_id"]       = $row->fid;
				    $data["name"]           = $friend_info->name;
				    $data["privacy"]        = '0';
				    $data["unique_content"] = (int)post("unique_content")?1:0;
				    $data["unique_link"]    = (int)post("unique_link")?1:0;
				    $data["time_post"]      = date("Y-m-d H:i:s", strtotime(NOW) + rand(3000,5000));
				    $data["time_post_show"] = $data["time_post"];
				    $data["status"]         = 1;
				    $data["deplay"]         = $deplay;
				    $data["changed"]        = NOW;
				    $data["created"]        = NOW;
				    
				    $this->db->insert(FACEBOOK_SCHEDULES, $data);
				  //  print_r ($data);
				  
                } 
            }
        }
	}

    
	public function post(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);
        
	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where('category', 'post')
	    ->where('time_post <= ', NOW)
	    ->get()->result();

		if(!empty($result)){
			foreach ($result as $key => $row) {
			    
			    $arr_update = $row;
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;
                
                if($repeat == 8){
				    $time_post  = strtotime(NOW) + $repeat_time -rand(120,180);
                }else{
                    $time_post          = strtotime(NOW) + $repeat_time;
                }
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				$row->message     = $spintax->process($row->message);
				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
               
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);
                    
					if($repeat == 1 && $time_post_day <= $repeat_end){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}
					
					if($repeat == 8){
				        $get_data = $this->model->fetch("*", save_data, "status = 1 and cat_data = '".$row->cat_data."'");
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$rand_data = rand(0, (count($get_data)-1));
          				$data2 = (array)$get_data[$rand_data];
						$arr_update['category']    = $data2[category];
				        $arr_update['type']        = $data2[type];
						$arr_update['url']         = $data2[url];
						$arr_update['image']       = $data2[image];
						$arr_update['title']       = $data2[title];
						$arr_update['caption']     = $data2[caption];
						$arr_update['description'] = $data2[description];
						$arr_update['message']     = $data2[message];
						$arr_update['cat_data']    = $row->cat_data;
				    	
				    	$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
				    //	$this->db->update(FACEBOOK_SCHEDULES ,$arr_update);
                    }
                    
					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
					//	'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
					//$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
					$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
				}
				                   
			}
		}

    echo l('Successfully');
	}

	public function post_friend(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);


	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where('category', 'friend')
	    ->where('time_post <= ', NOW)
	    ->get()->result();

		if(!empty($result)){
			foreach ($result as $key => $row) {
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;

				$time_post          = strtotime(NOW) + $repeat_time;
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				$row->message     = $spintax->process($row->message);
				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);

					if($repeat == 1 && $time_post_day <= $repeat_end){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}

					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
						'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
					//$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
					$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
				}
			}
		}

    echo l('Successfully');
	}

	public function join(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);


	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where('category', 'join')
	    ->where('time_post <= ', NOW)
	    ->get()->result();

		if(!empty($result)){
			foreach ($result as $key => $row) {
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;

				$time_post          = strtotime(NOW) + $repeat_time;
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				$row->message     = $spintax->process($row->message);
				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);

					if($repeat == 1 && $time_post_day <= $repeat_end){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}

					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
						'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
				//	$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
				}
			}
		}
    echo l('Successfully');
	}

	public function add_friend(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);


	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where('category', 'add')
	    ->where('time_post <= ', NOW)
	    ->get()->result();

		if(!empty($result)){
			foreach ($result as $key => $row) {
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;

				$time_post          = strtotime(NOW) + $repeat_time;
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				$row->message     = $spintax->process($row->message);
				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);

					if($repeat == 1 && $time_post_day <= $repeat_end){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}

					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
						'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
					//$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
					$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
				}
			}
		}
    echo l('Successfully');
	}

	public function unfriends(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);


	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where('category', 'unfriends')
	    ->where('time_post <= ', NOW)
	    ->get()->result();

		if(!empty($result)){
			foreach ($result as $key => $row) {
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;

				$time_post          = strtotime(NOW) + $repeat_time;
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				$row->message     = $spintax->process($row->message);
				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);

					if($repeat == 1 && $time_post_day <= $repeat_end){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}

					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
						'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
					//$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
					$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
				}
			}
		}
    echo l('Successfully');
	}

	public function invite_to_groups(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);


	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where('category', 'invite_to_groups')
	    ->where('time_post <= ', NOW)
	    ->get()->result();

		if(!empty($result)){
			foreach ($result as $key => $row) {
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;

				$time_post          = strtotime(NOW) + $repeat_time;
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				$row->message     = $spintax->process($row->message);
				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);

					if($repeat == 1 && $time_post_day <= $repeat_end){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}

					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
						'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
				//	$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
				}
			}
		}

    echo l('Successfully');
	}

	public function invite_to_pages(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);


	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where('category', 'invite_to_pages')
	    ->where('time_post <= ', NOW)
	    ->get()->result();

		if(!empty($result)){
			foreach ($result as $key => $row) {
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;

				$time_post          = strtotime(NOW) + $repeat_time;
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				$row->message     = $spintax->process($row->message);
				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);

					if($repeat == 1 && $time_post_day <= $repeat_end){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}

					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
						'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
				//	$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
					$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
				}
			}
		}
    echo l('Successfully');
	}

	public function accept_friend_request(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);


	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where('category', 'accept_friend_request')
	    ->where('time_post <= ', NOW)
	    ->get()->result();

		if(!empty($result)){
			foreach ($result as $key => $row) {
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;

				$time_post          = strtotime(NOW) + $repeat_time;
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				$row->message     = $spintax->process($row->message);
				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);

					if($repeat == 1 && $time_post_day <= $repeat_end){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}

					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
						'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
					//$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
					$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
				}
			}
		}

    echo l('Successfully');
	}

	public function comment(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);


	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where("( category = 'comment' OR category = 'bulk_comment')")
	    ->where('time_post <= ', NOW)
	    ->get()->result();
        
        $get_comment = $this->model->fetch("*", SAVE_DATA, "cat_data = 'Comment'");
        
		if(!empty($result)){
			foreach ($result as $key => $row) {
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;

				$time_post          = strtotime(NOW) + $repeat_time;
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				if ($row->auto_comment == 0){
				    $row->message  = $get_comment[rand(0,count($get_comment))]->message;
				}else{ 
				    $row->message     = $spintax->process($row->message); 
			}

				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);

					if($repeat == 1 && $time_post_day <= $repeat_end){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}

					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
						'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
					//$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				//	$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
				}
			}
		}

    	echo l('Successfully');
	}


    public function auto_like (){
         echo '<pre>';
        $result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status = ', 9)
	    ->where("(category = 'bulk_like')")
	    ->where('time_post <= ', NOW)
	    ->get()->result();
        //print_r ($result);
		$get_acclike  =  $this->model->fetch("*", token, "status = 1");
		if(!empty($result)){
			foreach ($result as $key => $row) {
			    if ($row->bot_like == 0){
		        //	$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
		        }else{
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;
                $bot_like     = $row->bot_like;
                $check_status = $row->status;
               
                $time_post          = strtotime(NOW) + rand(180,300);
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
			//	$arr_update         = $row;
				$repeat_end         = strtotime($repeat_end);
//print_r ($row);
                $row->access_token = $get_acclike[$bot_like]->token;
	            $row->username = "0";
	            $row->password = "0";
	            $row->cookies = "0";
	            $row->fid = "0";
	            
                $response = (object)Fb_Post((object)$row);
                $arr_update["bot_like"] = $row->bot_like -1;

    	        $arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);
		        $arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
		        $arr_update["result"] = (isset($response->id) && $response->id != "")?$response->id:"";
	    	    $arr_update["message_error"] = (isset($response->txt) && $response->txt != "")?$response->txt:"";
			    $arr_update['status'] = $row->status;
	    	    $this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
			}}
		}
    }
    
	public function like(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);

	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where('status != ', 9)
	    ->where("( category = 'like' OR category = 'bulk_like')")
	    ->where('time_post <= ', NOW)
	    ->get()->result();

		if(!empty($result)){
			foreach ($result as $key => $row) {
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;
                $bot_like     = $row->bot_like;
                $check_status = $row->status;
                $time_post          = strtotime(NOW) + $repeat_time;
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				$row->message     = $spintax->process($row->message);
				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
				
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'status' => ($response->st == "success")?3:4,
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);

					if($repeat == 1 && $time_post_day <= $repeat_end){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}

					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
						'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
					$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
					//$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}
			}
		}

    echo l('Successfully');
	}

	public function repost_pages(){
		$spintax = new Spintax();
		ini_set('max_execution_time', 300000);


	 	$result = $this->db
	    ->select('*')
	    ->from(FACEBOOK_SCHEDULES)
	    ->where('status != ', 2)
	    ->where('status != ', 3)
	    ->where('status != ', 4)
	    ->where('category', 'repost_pages')
	    ->where('time_post <= ', NOW)
	    ->get()->result();

		if(!empty($result)){
			foreach ($result as $key => $row) {
				$delete       = $row->delete_post;
				$repeat       = $row->repeat_post;
				$repeat_time  = $row->repeat_time;
				$repeat_end   = $row->repeat_end;
				$time_post    = $row->time_post;
				$deplay       = $row->deplay;

				$time_post          = strtotime(NOW) + $deplay;
				$time_post_only_day = date("Y-m-d", $time_post);
				$time_post_day      = strtotime($time_post_only_day);
				$repeat_end         = strtotime($repeat_end);

				$row->url         = $spintax->process($row->url);
				$row->message     = $spintax->process($row->message);
				$row->title       = $spintax->process($row->title);
				$row->description = $spintax->process($row->description);
				$row->image       = $spintax->process($row->image);
				$row->caption     = $spintax->process($row->caption);

				$account = $this->model->get("*", FACEBOOK_ACCOUNTS, "id = '".$row->account_id."'");
				if(!empty($account)){
					$row->access_token = $account->access_token;
					$row->username = $account->username;
					$row->password = $account->password;
					$row->cookies = $account->cookies;
					$row->fid = $account->fid;

					$response = (object)Fb_Post((object)$row);
					$arr_update = array(
						'result' => (isset($response->id) && $response->id != "")?$response->id:"",
						'message_error' => (isset($response->txt) && $response->txt != "")?$response->txt:""
					);

					if($repeat == 1){
						$arr_update['status']    = 5;
						$arr_update['time_post'] = date("Y-m-d H:i:s", $time_post);

						$user = $this->model->get("*", USER_MANAGEMENT, "id = '".$row->uid."'");
						if(!empty($user)){
							$date = new DateTime(date("Y-m-d H:i:s", $time_post), new DateTimeZone(TIMEZONE_SYSTEM));
							$date->setTimezone(new DateTimeZone($user->timezone));
							$time_post_show = $date->format('Y-m-d H:i:s');
							$arr_update['time_post_show'] = $time_post_show;
						}else{
							$arr_update['time_post_show'] = date("Y-m-d H:i:s", $time_post);
						}
					}

					$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
				}else{
					$arr_update = array(
						'status' => 4,
						'message_error' => l('Facebook account not exist')
					);
				//	$this->db->update(FACEBOOK_SCHEDULES ,$arr_update , "id = {$row->id}");
					$this->db->delete(FACEBOOK_SCHEDULES, "title = {$row->title}");
				}
			}
		}

    echo l('Successfully');
	}
}
