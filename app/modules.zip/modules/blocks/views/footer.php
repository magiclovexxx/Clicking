<div class="footer">
    <div class="container wide">
        <div class="row">
            <div class="col-md-9 coptright"><?=l('2016 - 2017 © T$T. All rights reserved.')?></div>
            <div class="col-md-3 text-right social">
              <a href="https://www.facebook.com/mailerlite/">
                <img src="<?=BASE?>assets/images/facebook.png" alt="Share this with Facebook" class="social-icons">
              </a>
              <a href="https://twitter.com/mailerlite">
                <img src="<?=BASE?>assets/images/twitter.png" alt="Share this with Twitter" class="social-icons"> 
              </a>
              <a href="https://uk.pinterest.com/mailerlite/">
                <img src="<?=BASE?>assets/images/pinterest.png" alt="Share this with Pinterest" class="social-icons">
              </a>
              <a href="https://www.instagram.com/mailerlite/">
                <img src="<?=BASE?>assets/images/instagram.png" alt="Share this with Instagram" class="social-icons">
              </a>
            </div>
        </div>
    </div>
</div>